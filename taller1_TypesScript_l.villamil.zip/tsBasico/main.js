"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const seriesTbody = document.getElementById("series"); // Nodo tbody que tiene el id="series"
function renderSeriesInTable(series) {
    series.forEach(c => {
        let trElement = document.createElement("tr");
        trElement.innerHTML = `<td>${c.id}</td>
                             <td>${c.name}</td>
                             <td>${c.seasons}</td>`;
        seriesTbody.appendChild(trElement);
    });
}
