import { Serie } from './serie.js';
import {series} from './data.js';
const seriesTbody: HTMLElement = document.getElementById("series")!; // Nodo tbody que tiene el id="series"
const seasonsAverage: HTMLElement = document.getElementById("seasons-average")!; // Nodo tbody que tiene el id="series"
function renderSeriesInTable(series: Serie[]): void {
    series.forEach(c => {
      let trElement = document.createElement("tr");
      trElement.innerHTML = `<td>${c.id}</td>
                             <td>${c.name}</td>
                             <td>${c.seasons}</td>`;
      seriesTbody.appendChild(trElement);
    });
  }


  function getSeasonsAverage(series: Serie[]): number {
    let sum: number = 0;
    series.forEach((serie) => sum = sum + serie.seasons);
    let numSeries:number= series.length;
    return sum/numSeries;
  }
